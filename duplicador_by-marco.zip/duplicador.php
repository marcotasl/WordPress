<?php
/*
Plugin Name: Duplicador
Plugin URI: https://omarcolobo.com/
Description: Duplique posts e páginas facilmente, com um único clique. 
Version: 1.0.0
Author: Marco Lobo
Author URI: https://omarcolobo.com
*/

// Adiciona o botão de duplicação nos posts e páginas

add_action('post_row_actions', 'add_duplicate_post_link', 10, 2);
add_action('page_row_actions', 'add_duplicate_post_link', 10, 2);

function add_duplicate_post_link($actions, $post){
    // Checa se o usuário tem permissão para editar o post
    if (current_user_can('edit_posts')){
        // Adiciona o link de duplicação aos actions
        $actions['duplicate'] = '<a href="' . wp_nonce_url('admin.php?action=duplicate_post_as_draft&post=' . $post->ID, basename(__FILE__), 'duplicate_nonce') . '" title="Duplicar este item" rel="permalink">Duplicar</a>';
    }
    return $actions;
}

// Registra o novo status de post "Duplicado"
add_action('init', 'register_duplicate_post_status');

function register_duplicate_post_status(){
    register_post_status('duplicate', array(
        'label'                     => _x('Duplicado', 'post'),
        'public'                    => true,
        'exclude_from_search'       => true,
        'show_in_admin_all_list'    => true,
        'show_in_admin_status_list' => true,
        'label_count'               => _n_noop('Duplicados <span class="count">(%s)</span>', 'Duplicados <span class="count">(%s)</span>')
    ));
}

// Duplica o post como um draft e redireciona para a tela de edição do novo post
add_action('admin_action_duplicate_post_as_draft', 'duplicate_post_as_draft');

function duplicate_post_as_draft(){
    global $wpdb;
    // Checa se o nonce está correto
    if (!isset($_GET['duplicate_nonce']) || !wp_verify_nonce($_GET['duplicate_nonce'], basename(__FILE__))){
        return;
    }
    // Pega o ID do post original
    $post_id = isset($_GET['post']) ? absint($_GET['post']) : '';
    // Pega o post original
    $post = get_post($post_id);
    // Copia o post para um novo rascunho
    $new_post = array(
        'post_title'    => $post->post_title . ' (Duplicado)',
        'post_content'  => $post->post_content,
        'post_status'   => 'draft',
        'post_type'     => $post->post_type,
        'post_author'   => $post->post_author
    );
    // Insere o novo post no banco de dados
    $new_post_id = wp_insert_post($new_post);
    // Copia os metadados do post original para o novo post
    $post_meta_infos = $wpdb->get_results("SELECT meta_key, meta_value FROM $wpdb->postmeta WHERE post_id=$post_id");
    if (count($post_meta_infos) != 0){
        $sql_query_sel = [];
        $sql_query_ins = [];
        foreach ($post_meta_infos as $meta_info){
            $meta_key = $meta_info->meta_key;
            if ($meta_key == '_wp_old_slug') continue; // Ignora o meta_key "_wp_old_slug"
            $meta_value = addslashes($meta_info->meta_value);
            $sql_query_sel[] = "SELECT $new_post_id, '$meta_key', '$meta_value'";
    }
    // Insere os metadados do post original no novo post
    $wpdb->query("INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) ". implode(' UNION ALL ', $sql_query_sel));
    $wpdb->query("INSERT INTO $wpdb->postmeta (post_id, meta_key, meta_value) VALUES " . implode(',', $sql_query_ins));
}
// Altera o status do post original para "Duplicado"
wp_update_post(array(
    'ID'            => $post_id,
    'post_status'   => 'duplicate'
));
// Redireciona para a tela de edição do novo post
wp_redirect(admin_url('post.php?action=edit&post=' . $new_post_id));
exit;
}
?>